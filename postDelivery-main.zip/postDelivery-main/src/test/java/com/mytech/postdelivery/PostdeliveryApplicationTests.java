package com.mytech.postdelivery;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class PostdeliveryApplicationTests {

    @Test
    void contextLoads() {
    }

}
